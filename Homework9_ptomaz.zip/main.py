### YOUR CODE GOES BELOW

### USING argparse

import argparse
import helper

parser = argparse.ArgumentParser()
parser.add_argument("x", type=int, help="first number")
parser.add_argument("y", type=int, help="second number")

args = parser.parse_args()

print "The sum is: %s" % helper.add2(args.x, args.y)

### END CODE