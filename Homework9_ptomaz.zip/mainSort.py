### YOUR CODE GOES BELOW

### USING argparse

import argparse
import sorthelper

parser = argparse.ArgumentParser()
#parser.add_argument('--nargs-int-type', nargs='+', type=int)
parser.add_argument("userList", nargs="+", type=int, help="Expecting a list of numbers to sort.")

args = parser.parse_args()
#print args.userList
#print sorted(args.userList)
#print args.userList.sort()
print "The ascending order list is: %s" % sorthelper.sortNumbers(args.userList)


### END CODE