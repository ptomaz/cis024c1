
### YOUR CODE GOES BELOW

import argparse

parser = argparse.ArgumentParser()
parser.add_argument("x", type=int, help="first number")
parser.add_argument("y", type=int, help="second number")

args = parser.parse_args()

def add2(x,y):
    return x+y

#firstNum = int(raw_input("I will need 2 numbers to add.  Enter the first number: "))
#secondNum = int(raw_input("Enter the second number: "))

print "The sum is: %s" % add2(args.x, args.y)

### END CODE