### YOUR CODE GOES BELOW

import sys
import sorthelper

userList = sys.argv[1::]
userList = map(int, userList)

print "The ascending order list is: %s" % sorthelper.sortNumbers(userList)

    
### END CODE