
### YOUR CODE GOES BELOW

#import sys
def add2(x,y):
    return x+y

firstNum = input("I will need 2 numbers to add.  Enter the first number: ")
secondNum = input("Enter the second number: ")

print "The sum is: %s" % add2(firstNum,secondNum)

### END CODE