### YOUR CODE GOES BELOW

def add2(x,y):
    return x+y

### END CODE