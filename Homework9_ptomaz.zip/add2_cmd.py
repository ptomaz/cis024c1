
### YOUR CODE GOES BELOW

### USING sys.argv

import sys

def add2(x,y):
    return x+y

#firstNum = int(raw_input("I will need 2 numbers to add.  Enter the first number: "))
#secondNum = int(raw_input("Enter the second number: "))

print "The sum is: %s" % add2(int(sys.argv[1]), int(sys.argv[2]))

### END CODE