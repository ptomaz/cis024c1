### YOUR CODE GOES BELOW

### USING argparse

import sys
import helper

print "The sum is: %s" % helper.add2(int(sys.argv[1]), int(sys.argv[2]))

### END CODE