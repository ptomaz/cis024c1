
from collections import OrderedDict

def wordDistance(word1,word2):
    
   # if len(word1) == 0:
    #    print "Please provide a valid word"
     #   return "INVALID_ENTRY"
    
    #print word1,word2
    dictWord={}
    letterCount=0
    if len(word1)<=len(word2):
        letterCount=len(word1)
    else:
        letterCount=len(word2)
    #print letterCount
    editDistance=0
    for i in range(letterCount):
        letterDistance=ord(word1[i])-ord(word2[i])
        #print ord(word1[i]),ord(word2[i])
        #print word1[i],word2[i],letterDistance
        editDistance+=abs(letterDistance)
        #print editDistance
    dictWord[word2]=editDistance
    #return abs(editDistance),word2
    return dictWord


def similarly(inputWord,userWords):
    # get list of words that share the relatively same size +/- 1 letter
    #print userWords
    # perform similarity comparison
    bestMatchWords = {}
    bestWords = {}
    liBestWords = []

#make a dict of all best match words and sort by match count
#return a list of top three best matches
    for entry in userWords:
        #print entry
        matchCount = 0
        for l1 in entry:
            #print "letter:",l1
            if l1 in inputWord:
                matchCount += 1
            bestMatchWords[entry]=matchCount
                #print bestMatchWords
    bestWords=OrderedDict(sorted(bestMatchWords.items(), key=lambda x:x[1],reverse=True))
    liBestWords = list(bestWords)[:3]
    #print bestWords
    return liBestWords

def alternativeWords(misspelled,wordCorpus):
    candidateWords = []
    dictWordDist={}
    userWord={}

    inputWord=misspelled

    #exit if no word is entered
    if len(inputWord) == 0:
        print "Please provide a valid word"
        exit

    #exit if word is spelled correctly
    for entry in wordCorpus:
        if inputWord.lower()==entry:
            print "Correctly spelled word"
            exit

    lowerWordLen = len(inputWord) - 1
    upperWordLen = len(inputWord) + 1

    # get the list of candidate words
    #candidateWords = []

    for entry in wordCorpus:     
        if len(entry) >= lowerWordLen and len(entry) <= upperWordLen:
            candidateWords.append(entry)      
    #print candidateWords

    #################### calculate word distance for each candidate word ######################
    from collections import OrderedDict
    #dictWordDist={}
    #userWord={}
    #for i in range(0,1361):
    for i in range(0,len(candidateWords)):
        #if flag=="False":
        dictWordDist.update(wordDistance(inputWord,candidateWords[i]))
        #else:
         #   break

    #print sorted(dictWordDist.items(), key=lambda x:x[1])
    userWord=OrderedDict(sorted(dictWordDist.items(), key=lambda x:x[1]))
    #print list(userWord.items())[:25]
    #print list(userWord)[:25]

    ################ def similarly(inputWord,userWords): ########################  

    #print "Input word:",inputWord
    userWord1=list(userWord)[:25]
    #print userWord1
    #print "Best alternatives are: %s" % ", ".join(map(str, similarly(inputWord,userWord1)))
    print "Best alternatives for %s are: %s" % (inputWord, ", ".join(map(str, similarly(inputWord,userWord1)))) 

    return