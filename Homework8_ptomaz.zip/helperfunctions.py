def add(x,y):
    return x+y

def diff(x,y):
    return x-y

def product(x,y):
    return x*y

def greatest(x,y):
    return max(x,y)
